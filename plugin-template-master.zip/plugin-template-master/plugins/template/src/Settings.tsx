import { Forms } from "@vendetta/ui/components";
const { FormText } = Forms;

export default () => (
    <FormText>
        Hello, world!
    </FormText>
)