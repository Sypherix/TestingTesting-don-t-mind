# Vendetta Plugins Template
This repo contains a template for creating [Vendetta](https://github.com/vendetta-mod/Vendetta) plugins.

# How to install?
Paste a plugin URL into the Plugins page of Vendetta, following a basic format of:

https://`YOUR_GITHUB_USERNAME`.github.io/`REPO_NAME`/`PLUGIN_NAME`